import React from 'react'

export default function Footer() {
    return (
        <div style={{border:'solid black 2px ',padding:'10px'}}>
            footer
        </div>
    )
}
